# Contribution Statement

This project was prepared by:

- Tushar Singh (22322032)
- Pranav Pipariya (22322022)
- Tanishq Gupta (22322031)
- Kavish Jain (22322017)
- Yash Kumar (22322034)

## Individual Contributions

**Tushar Singh** contributed to the pending-burden and COVID-period investigation, including pending-rate summaries, pending-days interpretation, and discussion of scrape-date limitations.

**Pranav Pipariya** contributed to the technical implementation and integration of the empirical workflow, including robust date parsing, validation checks, adjusted delay benchmarking, the NumPy long-delay risk model, output generation, and final notebook packaging.

**Tanishq Gupta** contributed to the bail-type landscape investigation, including interpretation of regular bail, anticipatory bail, and cancellation distributions across courts, years, and case-type conventions.

**Kavish Jain** contributed to the disposal-delay and court-inequality investigation, including court-level comparisons, disposal-time summaries, and interpretation of adjusted delay patterns.

**Yash Kumar** contributed to the observed-outcome investigation, including disposal-outcome label grouping, restricted-cohort interpretation, and outcome-coverage caveats.

## Shared Contributions

All members contributed to dataset selection, Phase 1 exploration, discussion of research directions, and review of the final empirical questions. The final notebook keeps one labeled empirical investigation per member while preserving a single coherent submission.
